=== Make it Rain ===
Tags: Money,RichPig,Blackcore
License: Blackcore
License URI: Blackcore.ir

== Description ==
with this script you can throw money/paper at air on click event or can be use customized for make it rain in one or multiple section in site . make money rain(script animation (not gif!)) everywhere in your site that you want. 